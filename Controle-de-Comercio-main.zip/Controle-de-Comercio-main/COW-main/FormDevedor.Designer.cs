﻿namespace COW
{
    partial class FormDevedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.listView17 = new System.Windows.Forms.ListView();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.listView2 = new System.Windows.Forms.ListView();
            this.listView6 = new System.Windows.Forms.ListView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listView13 = new System.Windows.Forms.ListView();
            this.listView16 = new System.Windows.Forms.ListView();
            this.listView14 = new System.Windows.Forms.ListView();
            this.listView15 = new System.Windows.Forms.ListView();
            this.listView10 = new System.Windows.Forms.ListView();
            this.listView11 = new System.Windows.Forms.ListView();
            this.listView12 = new System.Windows.Forms.ListView();
            this.listView7 = new System.Windows.Forms.ListView();
            this.listView8 = new System.Windows.Forms.ListView();
            this.listView9 = new System.Windows.Forms.ListView();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.listView5 = new System.Windows.Forms.ListView();
            this.listView4 = new System.Windows.Forms.ListView();
            this.listView3 = new System.Windows.Forms.ListView();
            this.btnVenda = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.btnProduto = new System.Windows.Forms.Button();
            this.btnPerfil = new System.Windows.Forms.Button();
            this.btnDevedor = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox11.Location = new System.Drawing.Point(859, 85);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(301, 20);
            this.textBox11.TabIndex = 55;
            this.textBox11.Text = "Nome do Cliente com Divida";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.listView17);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.listView1);
            this.groupBox1.Controls.Add(this.listView2);
            this.groupBox1.Controls.Add(this.listView6);
            this.groupBox1.Location = new System.Drawing.Point(729, 111);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(503, 509);
            this.groupBox1.TabIndex = 54;
            this.groupBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(232, 456);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 20);
            this.label3.TabIndex = 63;
            this.label3.Text = "Valor Total";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox8.Location = new System.Drawing.Point(393, 19);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 20);
            this.textBox8.TabIndex = 40;
            this.textBox8.Text = "Valor Total";
            // 
            // listView17
            // 
            this.listView17.HideSelection = false;
            this.listView17.Location = new System.Drawing.Point(323, 440);
            this.listView17.Name = "listView17";
            this.listView17.Size = new System.Drawing.Size(174, 61);
            this.listView17.TabIndex = 62;
            this.listView17.UseCompatibleStateImageBehavior = false;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox9.Location = new System.Drawing.Point(272, 19);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(115, 20);
            this.textBox9.TabIndex = 39;
            this.textBox9.Text = "Quantidade";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox10.Location = new System.Drawing.Point(6, 19);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(254, 20);
            this.textBox10.TabIndex = 36;
            this.textBox10.Text = "Nome do Produto";
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(393, 45);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(100, 61);
            this.listView1.TabIndex = 38;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // listView2
            // 
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(272, 45);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(115, 61);
            this.listView2.TabIndex = 37;
            this.listView2.UseCompatibleStateImageBehavior = false;
            // 
            // listView6
            // 
            this.listView6.HideSelection = false;
            this.listView6.Location = new System.Drawing.Point(6, 45);
            this.listView6.Name = "listView6";
            this.listView6.Size = new System.Drawing.Size(254, 61);
            this.listView6.TabIndex = 36;
            this.listView6.UseCompatibleStateImageBehavior = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.textBox16);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.listView13);
            this.groupBox2.Controls.Add(this.listView16);
            this.groupBox2.Controls.Add(this.listView14);
            this.groupBox2.Controls.Add(this.listView15);
            this.groupBox2.Controls.Add(this.listView10);
            this.groupBox2.Controls.Add(this.listView11);
            this.groupBox2.Controls.Add(this.listView12);
            this.groupBox2.Controls.Add(this.listView7);
            this.groupBox2.Controls.Add(this.listView8);
            this.groupBox2.Controls.Add(this.listView9);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.listView5);
            this.groupBox2.Controls.Add(this.listView4);
            this.groupBox2.Controls.Add(this.listView3);
            this.groupBox2.Location = new System.Drawing.Point(217, 111);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(493, 509);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(222, 456);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 61;
            this.label1.Text = "Valor Total";
            // 
            // listView13
            // 
            this.listView13.HideSelection = false;
            this.listView13.Location = new System.Drawing.Point(393, 246);
            this.listView13.Name = "listView13";
            this.listView13.Size = new System.Drawing.Size(100, 61);
            this.listView13.TabIndex = 49;
            this.listView13.UseCompatibleStateImageBehavior = false;
            // 
            // listView16
            // 
            this.listView16.HideSelection = false;
            this.listView16.Location = new System.Drawing.Point(313, 440);
            this.listView16.Name = "listView16";
            this.listView16.Size = new System.Drawing.Size(174, 61);
            this.listView16.TabIndex = 60;
            this.listView16.UseCompatibleStateImageBehavior = false;
            // 
            // listView14
            // 
            this.listView14.HideSelection = false;
            this.listView14.Location = new System.Drawing.Point(272, 246);
            this.listView14.Name = "listView14";
            this.listView14.Size = new System.Drawing.Size(115, 61);
            this.listView14.TabIndex = 48;
            this.listView14.UseCompatibleStateImageBehavior = false;
            // 
            // listView15
            // 
            this.listView15.HideSelection = false;
            this.listView15.Location = new System.Drawing.Point(6, 246);
            this.listView15.Name = "listView15";
            this.listView15.Size = new System.Drawing.Size(254, 61);
            this.listView15.TabIndex = 47;
            this.listView15.UseCompatibleStateImageBehavior = false;
            // 
            // listView10
            // 
            this.listView10.HideSelection = false;
            this.listView10.Location = new System.Drawing.Point(393, 179);
            this.listView10.Name = "listView10";
            this.listView10.Size = new System.Drawing.Size(100, 61);
            this.listView10.TabIndex = 46;
            this.listView10.UseCompatibleStateImageBehavior = false;
            // 
            // listView11
            // 
            this.listView11.HideSelection = false;
            this.listView11.Location = new System.Drawing.Point(272, 179);
            this.listView11.Name = "listView11";
            this.listView11.Size = new System.Drawing.Size(115, 61);
            this.listView11.TabIndex = 45;
            this.listView11.UseCompatibleStateImageBehavior = false;
            // 
            // listView12
            // 
            this.listView12.HideSelection = false;
            this.listView12.Location = new System.Drawing.Point(6, 179);
            this.listView12.Name = "listView12";
            this.listView12.Size = new System.Drawing.Size(254, 61);
            this.listView12.TabIndex = 44;
            this.listView12.UseCompatibleStateImageBehavior = false;
            // 
            // listView7
            // 
            this.listView7.HideSelection = false;
            this.listView7.Location = new System.Drawing.Point(393, 112);
            this.listView7.Name = "listView7";
            this.listView7.Size = new System.Drawing.Size(100, 61);
            this.listView7.TabIndex = 43;
            this.listView7.UseCompatibleStateImageBehavior = false;
            // 
            // listView8
            // 
            this.listView8.HideSelection = false;
            this.listView8.Location = new System.Drawing.Point(272, 112);
            this.listView8.Name = "listView8";
            this.listView8.Size = new System.Drawing.Size(115, 61);
            this.listView8.TabIndex = 42;
            this.listView8.UseCompatibleStateImageBehavior = false;
            // 
            // listView9
            // 
            this.listView9.HideSelection = false;
            this.listView9.Location = new System.Drawing.Point(6, 112);
            this.listView9.Name = "listView9";
            this.listView9.Size = new System.Drawing.Size(254, 61);
            this.listView9.TabIndex = 41;
            this.listView9.UseCompatibleStateImageBehavior = false;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox7.Location = new System.Drawing.Point(393, 19);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 40;
            this.textBox7.Text = "Valor Total";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox6.Location = new System.Drawing.Point(272, 19);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(115, 20);
            this.textBox6.TabIndex = 39;
            this.textBox6.Text = "Quantidade";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox4.Location = new System.Drawing.Point(6, 19);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(254, 20);
            this.textBox4.TabIndex = 36;
            this.textBox4.Text = "Nome do Produto";
            // 
            // listView5
            // 
            this.listView5.HideSelection = false;
            this.listView5.Location = new System.Drawing.Point(393, 45);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(100, 61);
            this.listView5.TabIndex = 38;
            this.listView5.UseCompatibleStateImageBehavior = false;
            // 
            // listView4
            // 
            this.listView4.HideSelection = false;
            this.listView4.Location = new System.Drawing.Point(272, 45);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(115, 61);
            this.listView4.TabIndex = 37;
            this.listView4.UseCompatibleStateImageBehavior = false;
            // 
            // listView3
            // 
            this.listView3.HideSelection = false;
            this.listView3.Location = new System.Drawing.Point(6, 45);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(254, 61);
            this.listView3.TabIndex = 36;
            this.listView3.UseCompatibleStateImageBehavior = false;
            // 
            // btnVenda
            // 
            this.btnVenda.Location = new System.Drawing.Point(12, 63);
            this.btnVenda.Name = "btnVenda";
            this.btnVenda.Size = new System.Drawing.Size(153, 87);
            this.btnVenda.TabIndex = 47;
            this.btnVenda.Text = "Vendas";
            this.btnVenda.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox5.Location = new System.Drawing.Point(320, 85);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(301, 20);
            this.textBox5.TabIndex = 52;
            this.textBox5.Text = "Nome do Cliente com Divida";
            // 
            // btnProduto
            // 
            this.btnProduto.Location = new System.Drawing.Point(12, 228);
            this.btnProduto.Name = "btnProduto";
            this.btnProduto.Size = new System.Drawing.Size(153, 87);
            this.btnProduto.TabIndex = 48;
            this.btnProduto.Text = "Produtos";
            this.btnProduto.UseVisualStyleBackColor = true;
            // 
            // btnPerfil
            // 
            this.btnPerfil.Location = new System.Drawing.Point(12, 567);
            this.btnPerfil.Name = "btnPerfil";
            this.btnPerfil.Size = new System.Drawing.Size(153, 87);
            this.btnPerfil.TabIndex = 50;
            this.btnPerfil.Text = "Perfil";
            this.btnPerfil.UseVisualStyleBackColor = true;
            // 
            // btnDevedor
            // 
            this.btnDevedor.Location = new System.Drawing.Point(41, 405);
            this.btnDevedor.Name = "btnDevedor";
            this.btnDevedor.Size = new System.Drawing.Size(153, 87);
            this.btnDevedor.TabIndex = 49;
            this.btnDevedor.Text = "Devedores";
            this.btnDevedor.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 399);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(254, 20);
            this.textBox1.TabIndex = 60;
            this.textBox1.Text = "Código do Produto ou Nome";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(272, 399);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(115, 20);
            this.textBox16.TabIndex = 70;
            this.textBox16.Text = "Quantidade";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(393, 383);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 50);
            this.button3.TabIndex = 56;
            this.button3.Text = "Adicionar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(403, 384);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 50);
            this.button1.TabIndex = 71;
            this.button1.Text = "Adicionar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(282, 400);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(115, 20);
            this.textBox2.TabIndex = 73;
            this.textBox2.Text = "Quantidade";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(16, 400);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(254, 20);
            this.textBox3.TabIndex = 72;
            this.textBox3.Text = "Código do Produto ou Nome";
            // 
            // FormDevedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 761);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnVenda);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.btnProduto);
            this.Controls.Add(this.btnPerfil);
            this.Controls.Add(this.btnDevedor);
            this.Name = "FormDevedor";
            this.Text = "Devedores";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.ListView listView17;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ListView listView6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView13;
        private System.Windows.Forms.ListView listView16;
        private System.Windows.Forms.ListView listView14;
        private System.Windows.Forms.ListView listView15;
        private System.Windows.Forms.ListView listView10;
        private System.Windows.Forms.ListView listView11;
        private System.Windows.Forms.ListView listView12;
        private System.Windows.Forms.ListView listView7;
        private System.Windows.Forms.ListView listView8;
        private System.Windows.Forms.ListView listView9;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.Button btnVenda;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button btnProduto;
        private System.Windows.Forms.Button btnPerfil;
        private System.Windows.Forms.Button btnDevedor;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
    }
}