﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;

namespace COW
{
    public partial class FormCadastro : Form
    {
        conexao con = new conexao();
        public FormCadastro()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = con.getconexao();
            conexao.Open();
            string inserir1 = "insert into tb_cadastro(nome,datanascminto,telefone,cpf,email) values " + " (@nome,@datanascimento,@telefone,@cpf,@email)";
            MySqlCommand comando = new MySqlCommand(inserir1, conexao);
            comando.Parameters.AddWithValue("@nome", txt_nome.Text);
            comando.Parameters.AddWithValue("@datanascimento", txt_datanascimento.Text);
            comando.Parameters.AddWithValue("@cpf", txt_cpf.Text);
            comando.Parameters.AddWithValue("@email", txt_email.Text);
            comando.Parameters.AddWithValue("@telefone", txt_telefone.Text);
         
            comando.ExecuteReader();
            MessageBox.Show("Foi");
            conexao.Close();
        }
    }
}
