﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;

namespace COW
{
    public partial class FormNovProdu : Form
    {
        conexao con = new conexao();
        public FormNovProdu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = con.getconexao();
            conexao.Open();
            string inserir1 = "insert into tb_item(nome_item,valor,codigo) values " + " (@nome_item,@valor,@codigo)";
            MySqlCommand comando = new MySqlCommand(inserir1, conexao);
            comando.Parameters.AddWithValue("@nome_item", txt_nomeproduto.Text);
            comando.Parameters.AddWithValue("@valor", txt_valorproduto.Text);
            comando.Parameters.AddWithValue("@codigo", txt_codigoproduto.Text);
        

            comando.ExecuteReader();
            MessageBox.Show("Foi");
            conexao.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
